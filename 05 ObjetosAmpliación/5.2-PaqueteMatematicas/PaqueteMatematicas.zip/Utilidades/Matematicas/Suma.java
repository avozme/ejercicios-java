package Utilidades.matematicas;

class Suma {
	int suma(int a, int b) {
		return a + b;
	}

	double suma (double a, double b) {
		return a + b;
	}
}