package Utilidades.matematicas;

class Potencia {
	int potencia(int base, int exponente) {
		return (int)Math.pow(base, exponente);
	}

	double potencia(double base, int exponente) {
		return Math.pow(base, exponente);
	}
}